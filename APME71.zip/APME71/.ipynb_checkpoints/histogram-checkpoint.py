import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import norm

def histogram(df,y=0,bins=50,normed=False,normal=False,groupby='',group=''):
    fig,ax=plt.subplots(nrows=1)
    dfs=df[y].copy()
    if groupby !='':
        s=df[groupby].astype(str)==group 
        dfs=dfs[s]
    dfs=dfs.dropna()
    if normal:
        normed=True
        dfs=pd.DataFrame(dfs)
        minx=float(dfs[y].min())
        maxx=float(dfs[y].max())
        mean=float(dfs[y].mean())
        stdv=float(dfs[y].std())
        #print(minx,maxx,mean,stdv)
        xs=np.linspace(minx,maxx,1000)
        ys=norm(mean,stdv).pdf(xs)
        #print(ys)
        ys=pd.DataFrame(ys,index=xs,columns=['Normal'])
        ys.plot(ax=ax,title='Distribution')
    dfs.plot(kind='hist',y=y,bins=bins,density=normed,grid=True,ax=ax,color='grey')
    plt.show()
    return