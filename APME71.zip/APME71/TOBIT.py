# -*- coding: utf-8 -*-
"""
Created on Thu Dec  1 12:54:26 2016

@author: aes05kgb
"""

import numpy as np
import pandas as pd
from numpy.linalg import inv,cholesky,det,slogdet
import patsy
from patsy import dmatrix,dmatrices,ModelDesc
from scipy.stats import norm
from pandas import DataFrame as frame
from statsmodels.base.model import GenericLikelihoodModel
import scipy.stats as stats

def tobit_lik(y, X, beta, lsigma):
    mu = np.dot(X, beta)
    s0=y == 0
    s1=y != 0
    y0=y[s0]
    y1=y[s1]
    mu0=mu[s0]
    mu1=mu[s1]
    l1 = norm.logpdf(y1, mu1, np.exp(lsigma))
    if len(y0)>0:
        l0=norm.logcdf(-mu0,0,np.exp(lsigma))
        #l0=norm.logcdf(0,mu0,np.exp(lsigma))
        ll=l0.sum()+l1.sum()
    else:
        ll=l1.sum()
    return ll
    
class tobit_(GenericLikelihoodModel):
    def __init__(self, endog, exog, **kwds):
        super(tobit_, self).__init__(endog, exog, **kwds)

    def nloglikeobs(self, params):
        lsigma = params[-1]
        beta = params[:-1]
        ll = tobit_lik(self.endog, self.exog, beta, lsigma)
        return -ll

    def fit(self, start_params=None, maxiter=100000, maxfun=50000, **kwds):
        # we have one additional parameter and we need to add it for summary
        self.exog_names.append('logsigma')
        if start_params == None:
            # Reasonable starting values
            lx=np.array(self.exog)
            ly=np.array(self.endog)
            start_params0=(inv(lx.T@lx))@(lx.T@ly)
            
            start_params = np.append(start_params0, 0)
            #start_params = np.zeros(4)
            
            #print(start_params)
            # intercept
            #start_params[-2] = np.log(self.endog.mean())
        return super(tobit_, self).fit(start_params=start_params,
                                     maxiter=maxiter, maxfun=maxfun,
                                     **kwds)

def regTOBIT(y,x):
    res = tobit_(y,x)
    #print(res.summary())
    return res 

def tobit(formula,data,printit=True):
    formula=formula.replace('=','~')
    y,x=patsy.dmatrices(formula,data)
    y=frame(y)       
    x=frame(x,columns=[x.design_info.column_names])
    res=regTOBIT(y,x)
    return res

def tobitmeffects(mod1):
    beta=np.reshape(mod1.params,[len(mod1.params),1])
    se=np.reshape(mod1.bse,[len(mod1.params),1])
    X=pd.DataFrame(mod1.exog)
    mu=np.mean(X@beta[:-1])
    sigma=np.exp(beta[-1])
    cdf=np.exp(stats.norm.logcdf(0,mu,sigma))
    df=pd.DataFrame(np.concatenate([(1-cdf)*beta[1:-1],(1-cdf)*se[1:-1]],axis=1))
    df.index=mod1.model.exog_names[1:-1]
    df.columns=['ME','SE']
    return df