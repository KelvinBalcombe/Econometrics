#This takes the data for a regression and augments the data frame with errors, error-squared and squares of the explantory variables 
from pandas import DataFrame as frame
from pandas import concat
def augmentdata(mod1,squared=False):
    yhat=mod1.predict()
    y=mod1.model.endog
    e=y-yhat
    e2=e**2
    df=frame(mod1.model.exog)
    names=mod1.model.exog_names
    df.columns=names 
    
    if squared:
        df2=df.iloc[:,1:]**2
        names2=names[1:]
        j=0
        for i in names2:
            names2[j]=i+'2'
            j=j+1
        df2.columns=names2
        df=concat([df,df2],axis=1)
    
    df[mod1.model.endog_names]=mod1.model.endog
    df['yhat']=yhat
    df['yhat2']=yhat**2
    df['e']=e
    df['e2']=e2
    df['e_l']=df['e'].shift(1)
    return df