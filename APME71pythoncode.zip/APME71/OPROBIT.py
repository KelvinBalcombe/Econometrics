# -*- coding: utf-8 -*-
"""
Created on Thu Dec  1 12:54:26 2016

@author: aes05kgb
"""


import numpy as np
import pandas as pd
from numpy.linalg import inv,cholesky,det,slogdet
import patsy
from patsy import dmatrix,dmatrices,ModelDesc
from scipy.stats import norm
from pandas import DataFrame as frame
from statsmodels.base.model import GenericLikelihoodModel

def logi(x,mu):
    return(np.exp(x-mu)/(1+np.exp(x-mu)))

def twodma(y):
    return np.reshape(y,[len(y),1])

def findcats(y):
    #print(y)
    h=list()
    y=np.array(y)
    for i in range(10):
        s=np.sum(y==i)
        if s>0:
           h=h+[i]
    return h    

def oprobit_lik(y, X, beta, lamda,h):
    mu = np.dot(X, beta)
    mu = np.reshape(mu,[len(mu),1])
    j=1
    ll=0
    for i in h:
        s=y==i
        mui=mu[s]
        if j==1:
           l=norm.cdf(0,mui,1.0)
        elif j==2:
           l=norm.cdf(lamda[0],mui,1.0)- norm.cdf(0,mui,1.0)
        elif j<len(h):
           l=norm.cdf(lamda[j-2],mui,1.0)- norm.cdf(lamda[j-3],mui,1.0)
        else:
           l=norm.sf(lamda[len(lamda)-1],mui,1)
        ll=ll+np.log(l).sum()
        j=j+1
    return ll





def ologit_lik(y, X, beta, lamda,h):
    mu = np.dot(X, beta)
    mu = np.reshape(mu,[len(mu),1])
    j=1
    ll=0
    for i in h:
        s=y==i
        mui=mu[s]
        if j==1:
           l=logi(0,mui)
        elif j==2:
           l=logi(lamda[0],mui)- logi(0,mui)
        elif j<len(h):
           l=logi(lamda[j-2],mui)- logi(lamda[j-3],mui)
        else:
           l=1-logi(lamda[len(lamda)-1],mui)
        ll=ll+np.log(l).sum()
        j=j+1
    return ll

    
    
class oprobit(GenericLikelihoodModel):
    def __init__(self, endog, exog, **kwds):
        self.h=kwds['h']
        super(oprobit, self).__init__(endog, exog, **kwds)

    def nloglikeobs(self, params):
        k=len(self.h)-2
        lamda = params[-k:]
        beta = params[:-k]
        ll = oprobit_lik(self.endog, self.exog, beta, lamda,self.h)
        return -ll

    def fit(self, start_params=None, maxiter=100000, maxfun=50000, **kwds):
        # we have one additional parameter and we need to add it for summary
        #self.exog_names.append('lambda')
        if start_params == None:
            # Reasonable starting values
            lx=np.array(self.exog)
            ly=np.array(self.endog)
            start_params0=(inv(lx.T@lx))@(lx.T@ly)
            e=ly-lx@start_params0
            sde=np.sqrt(e.T@e)
            ly=ly/sde
            start_params0=(inv(lx.T@lx))@(lx.T@ly)
            
            bnd=0.5
            start_params = np.append(start_params0, bnd)
            u=len(self.h)-3
            bnd=bnd+0.5
            for i in range(u):
                start_params = np.append(start_params, bnd)
                bnd=bnd+0.5
            #start_params = np.zeros(4)
            #print('yes')
            #print(start_params)
            # intercept
            #start_params[-2] = np.log(self.endog.mean())
        return super(oprobit, self).fit(start_params=start_params,
                                     maxiter=maxiter, maxfun=maxfun,method='newton',
                                     **kwds)

    
class ologit(GenericLikelihoodModel):
    def __init__(self, endog, exog, **kwds):
        self.h=kwds['h']
        super(ologit, self).__init__(endog, exog, **kwds)

    def nloglikeobs(self, params):
        k=len(self.h)-2
        lamda = params[-k:]
        beta = params[:-k]
        ll = ologit_lik(self.endog, self.exog, beta, lamda,self.h)
        return -ll

    def fit(self, start_params=None, maxiter=100000, maxfun=50000, **kwds):
        # we have one additional parameter and we need to add it for summary
        #self.exog_names.append('lambda')
        if start_params == None:
            # Reasonable starting values
            lx=np.array(self.exog)
            ly=np.array(self.endog)
            start_params0=(inv(lx.T@lx))@(lx.T@ly)
            
            e=ly-lx@start_params0
            sde=np.sqrt(e.T@e)
            #lx=lx/sde
            ly=ly/sde
            start_params0=(inv(lx.T@lx))@(lx.T@ly)
            
            bnd=0.5
            start_params = np.append(start_params0, bnd)
            u=len(self.h)-3
            bnd=bnd+0.5
            for i in range(u):
                start_params = np.append(start_params, bnd)
                bnd=bnd+0.5
            #start_params = np.zeros(4)
            #print('yes')
            #print(start_params)
            # intercept
            #start_params[-2] = np.log(self.endog.mean())
        return super(ologit, self).fit(start_params=start_params,
                                     maxiter=maxiter, maxfun=maxfun,method='newton',
                                     **kwds)

    
def myOPROBIT(y,x):
    h=findcats(y)
    y=y.astype(float)
    res = oprobit(y,x,h=h)
    return res 

def myOLOGIT(y,x):
    h=findcats(y)
    y=y.astype(float)
    res = ologit(y,x,h=h)
    return res 


def ordinalreg(formula,data,typ='probit'):
    y_,x=patsy.dmatrices(formula,data)
    y=frame(y_)   
    #print(y)
    x=frame(x,columns=[x.design_info.column_names])
    #cc([y,x])
    if typ=='logit':
        res=myOLOGIT(y,x)
    else:
        res=myOPROBIT(y,x)
    return res



def oprobit_mfx_(y, X, beta, lamda,h):
    mu = np.dot(X, beta)
    mu = np.reshape(mu,[len(mu),1])
    mui=np.mean(mu)
    j=1
    ll=0
    meff=pd.DataFrame()
    #print(h)
    #print(lamda)
    for i in h:
        #print(j)
        #s=y==i
        #mui=mu[s]
        if j==1:
           l=norm.pdf(0,mui,1.0)
        elif j==2:
           l=norm.pdf(lamda[0],mui,1.0)- norm.pdf(0,mui,1.0)
        elif j<len(h):
           l=norm.pdf(lamda[j-2],mui,1.0)- norm.pdf(lamda[j-3],mui,1.0)
        else:
           l=-norm.pdf(lamda[len(lamda)-1],mui,1)
        c=np.array(-l*beta[1:,:])
        c_=pd.DataFrame(c)
        #c_.columns=[i]
        meff=pd.concat([meff,c_],axis=1)
        j=j+1
    return meff


def ologit_mfx_(y, X, beta, lamda,h):
    mu = np.dot(X, beta)
    mu = np.reshape(mu,[len(mu),1])
    mui=np.mean(mu)
    j=1
    ll=0
    meff=pd.DataFrame()
    for i in h:
        #print(j)
        #s=y==i
        #mui=mu[s]
        if j==1:
           l=derlogi(0,mui)
        elif j==2:
           l=derlogi(lamda[0],mui)-derlogi(0,mui)
        elif j<len(h):
           l=derlogi(lamda[j-2],mui)- derlogi(lamda[j-3],mui)
        else:
           l=-derlogi(lamda[len(lamda)-1],mui)
        c=np.array(-l*beta[1:,:])
        c_=pd.DataFrame(c)
        #c_.columns=[i]
        meff=pd.concat([meff,c_],axis=1)
        j=j+1
    return meff

def derlogi(l,mui):
    return logi(l,mui)*(1-logi(l,mui))


def mfx(mod,typ='probit'):
    X=mod.exog
    y=mod.endog
    k=np.shape(mod.exog)[1]
    beta=np.reshape(mod.params[:k],[len(mod.params[:k]),1])
    lamda=mod.params[k:]
    h=list(np.arange(0,len(lamda)+2))
    if typ=='logit':
        m=ologit_mfx_(y, X, beta, lamda,h)
        print('logit marginal effects')
    else:
        m=oprobit_mfx_(y, X, beta, lamda,h)
        print('probit marginal effects')
    names=mod.model.exog_names[1:k]
    #print('k',k,names,'h',h)
    #print(m)
    m.index=names
    m.columns=h
    #print('average marginal effects')
    a=(m*(np.array(h)+1)).T.sum()
    return m,a
