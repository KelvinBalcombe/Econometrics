#This file does the heteroscedasticity tests that are in gretl and not part of statsmodels
from statsmodels.regression.linear_model import OLS
from statsmodels.formula.api import ols
import numpy as np
from scipy.stats import chi2
import pandas as pd
from itertools import product
import augmentdata

def interactions(X,squaresonly=False):
    col1=X.columns
    col2=X.columns
    df = pd.DataFrame()
    if squaresonly:
        for i in product(col1, col2):
            if i[0]==i[1]:
                name = "*".join(i)
                df[name] = X[list(i)].prod(axis=1)
    else:
        for i in product(col1, col2):
            name = "*".join(i)
            df[name] = X[list(i)].prod(axis=1)
    df=pd.concat([X,df],axis=1)
    return df

#It is easy to create a set of lags in pandas by
#It is easy to create a set of lags in pandas by
def lagit(data,maxlag,y='y',replace=True):
    dat=data.copy()
    for i in range(1,maxlag+1):
        name=y+'_'+str(i)
        dat[name]=data[y].shift(i)
        if replace:
            for j in range(i):
                dat[name].iloc[j]=dat[y].iloc[0]
    return dat

#You can write a function to create the formula
def ARDL(data,y='y',x=['x1'],maxlag=[1,1],DL=True):
    f=y+'~'
    for i in range(1,maxlag[0]+1):
        name=y+'_'+str(i)
        f=f+'+'+name
    k=1
    for j in x:
        for i in range(0,maxlag[k]+1):
            if i>0 and DL:
                name=j+'_'+str(i)
            else:
                name=j
            f=f+'+'+name
            k=k+1
    L=max(maxlag)        
    data_=lagit(data,L,y=y,replace=False)
    for i in x:
        data_=lagit(data_,L,y=i,replace=False)
    return f,data_


#Gretl has a different version of the BP test as below
def breuschpagan(mod1):
    T=mod1.nobs              #Sample size
    rss=mod1.ssr             #residual sum of squares in model
    sigma2=np.sqrt(rss/T)    #Standard error of the residual (ML version)
    g=np.array((mod1.resid/sigma2)**2) #squared scaled residual
    names=mod1.model.exog_names
    X=pd.DataFrame(mod1.model.exog)
    X.columns=names
    g=pd.DataFrame(g)
    
    bp=OLS(g,X).fit()
 
    #print(bp.summary())
    g_total_sum_of_squares=bp.centered_tss
    g_sum_of_squared_errors=bp.ssr
    lm=.5*(g_total_sum_of_squares-g_sum_of_squared_errors)
    
    print('\ngretl_LMtest',lm, 'P-value', chi2.sf(lm,bp.df_model))
    return bp



def whites(mod0,squaresonly=False):
    T=int(mod0.nobs) 
    X=mod0.model.exog
    k=np.shape(X)[1]
    names=mod0.model.exog_names
    X=pd.DataFrame(X)
    X.columns=names
    X=interactions(X,squaresonly)
    e2=np.array((mod0.resid)**2)
    white=OLS(e2,X).fit()
    #print(white.summary())
    rsq=white.rsquared
    lm=T*rsq
    print('\nwhites_LMtest -squares only',lm, 'P-value', chi2.sf(lm,white.df_model))
    return white



def ramseyreset(mod1):
    T=int(mod1.nobs)  
    names=mod1.model.exog_names
    names=names+['yhat2']
    yhat2=np.reshape(mod1.predict(),[T,1])**2
    X=np.concatenate([mod1.model.exog,yhat2],axis=1)
    X=pd.DataFrame(X)
    X.columns=names
    ramsey=OLS(mod1.model.endog,X).fit()
    F=ramsey.tvalues[len(ramsey.tvalues)-1]**2
    print('\nRamsey Reset',F, 'P-value', ramsey.pvalues[len(ramsey.tvalues)-1])
    return ramsey

def BGtest(model):
    print('Note that the BG test here replaces the first missing lagged error with zero')
    data=augmentdata.augmentdata(model)
    data.loc[0,'e_l']=0
    names=model.model.exog_names
    form='e~'
    for i in names[1:]:
        form=form+'+' + i
    form=form + '+' + 'e_l'  
    #print(form)
    model1 = ols(form,data=data).fit()
    F=model1.tvalues[len(model1.tvalues)-1]**2
    print('\nBG test',F, 'P-value', model1.pvalues[len(model1.tvalues)-1])
    return(model1)

