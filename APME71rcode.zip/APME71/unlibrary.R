detach_package <- function(pkg, character.only = FALSE)
{
  if(!character.only)
  {
    pkg <- deparse(substitute(pkg))
  }
  search_item <- paste("package", pkg, sep = ":")
  while(search_item %in% search())
  {
    detach(search_item, unload = TRUE, character.only = TRUE)
  }
}

detach_package(dLagM)
detach_package(ivreg)
detach_package(forecast)
detach_package(Hmisc)
detach_package(restriktor)
detach_package(AER)

detach_package(orcutt)
detach_package(mfx)
detach_package(betareg)
detach_package(ggplot2)
detach_package(psych)
#detach_package(readxl)
detach_package(reshape2)
detach_package(wooldridge)
detach_package(car)
detach_package(carData)
detach_package(MASS)
detach_package(lmtest)
detach_package(sandwich)
detach_package(dynlm)
detach_package(zoo)
detach_package(nardl)

