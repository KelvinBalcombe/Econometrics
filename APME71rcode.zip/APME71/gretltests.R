
breuschpagan=function(mod0)
{
  df=summary(mod0)$df
  T=df[2]+df[3]
  dat=mod0$model
  e2=mod0$residuals^2
  rss=sum(e2)
  sigma2=sqrt(rss/T)
  Y=(mod0$residuals/sigma2)^2
  #Y=e2
  X_=data.matrix(dat[,2:ncol(dat)])
  md=lm(Y~X_)
  
  
  g_total_sum_of_squares=sum((Y-mean(Y))^2)
  yhat=md$fitted_values
  g_sum_of_squared_errors=sum(md$residuals^2)
  lm=.5*(g_total_sum_of_squares-g_sum_of_squared_errors)
  #obj=(summary(mod0))
  #list(str(obj))
  #list(str(mod0))
  print(c('BreuschPagan','LM:',lm,'P-val:',1-pchisq(lm,df[1]-1)))
  return(md)
}


whitessquareonly=function(mod0)
{
  dat=mod0$model
  e2=resid(mod0)**2
  Y=e2
  X_=dat[,2:ncol(dat)]
  XS=dat[,2:ncol(dat)]^2
  X=data.matrix(cbind(X_,XS))
  
  X=data.matrix(X)
  mod1=lm(Y~X)
  S=summary(mod1)
  
  rsq=as.numeric(summary(mod1)$r.squared)
  df=summary(mod1)$df
  N=as.numeric(df[1]+df[2])
  LM=N*rsq
  print(c('Whites LM test Squares','LM:', LM,'P-val:',1-pchisq(LM,df[1]-1)))
  return(S)}



whitesfull=function(mod0)
{
  dat=mod0$model
  e2=resid(mod0)**2
  Y=e2
  X_=dat[,2:ncol(dat)]
  for (i in 1:ncol(X_))
  {Z=X_[,i];
  for (j in i:ncol(X_))
  {W=X_[,j]
  Q=data.matrix(W*Z); #print (c(i,j))
  if (i==1 & j==1){V=cbind(X_,Q)} else {V=cbind(V,Q)}
  }
  }
  X=data.matrix(V)
  mod1=lm(Y~X)
  S=summary(mod1)
  
  rsq=as.numeric(summary(mod1)$r.squared)
  df=summary(mod1)$df
  N=as.numeric(df[1]+df[2])
  LM=N*rsq
  print(c('Whites LM test: Full','LM:', LM,'P-val:',1-pchisq(LM,df[1]-1)))
  return(S)}


ramseyreset=function(mod0)
{
  df=summary(mod0)$df
  T=df[2]+df[3]
  dat=mod0$model
  Y=dat[,1]
  yhat2=data.matrix(fitted.values(mod0)^2)
  X_=data.matrix(dat[,2:ncol(dat)])
  X_=cbind(X_,yhat2)
  md=lm(Y~X_)
  K=ncol(X_)+1
  outc=summary(md)$coefficients
  F=outc[K,'t value']^2
  p=outc[K,'Pr(>|t|)']
  print(c('Reset',F,p))
  return(md)
}

BGtest=function(mod0)
{
  df=summary(mod0)$df
  T=df[2]+df[3]
  dat=mod0$model
  
  e=data.matrix(residuals(mod0))
  
  e_=data.matrix(e[1:nrow(e),])
  e_l=data.matrix(e[1:(nrow(e)-1),])
  e_l=rbind(0,e_l)
  #e_l=data.matrix(e_l)
  
  X_=data.matrix(dat[,2:ncol(dat)])
  
  X_=cbind(X_,e_l)
  K=ncol(X_)+1
  md=lm(e~X_)
  outc=summary(md)$coefficients
  
  F=outc[K,'t value']^2
  p=outc[K,'Pr(>|t|)']
  print(c('BG',F,p))
  return(md)
}


  
