scatterplot=function(data=data,x='x',y='y',fill='grey',rline=TRUE)
{xs=x; ys=y
title=ggtitle(paste(xs,'and',ys))
center=theme(plot.title = element_text(hjust = 0.5))
xlb=xlab(xs)
ylb=ylab(ys)
line=geom_smooth(method='lm',colour=fill)
point=geom_point(colour='blue')
if (rline)
{ggplot(data,aes_string(x=xs,y=ys))+point+line+title+xlb+ylb+center}
else
{ggplot(data,aes_string(x=xs,y=ys))+point+title+xlb+ylb+center}  
}