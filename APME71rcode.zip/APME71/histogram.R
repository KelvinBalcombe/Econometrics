hist=function(df,w,norm=FALSE){m=mean(unlist(df[w]));s =sd(unlist(df[w]))
if (norm==TRUE)
{ggplot(df, aes_string(x = w))+geom_histogram(aes(y =..density..),bins=40,colour = "black",fill ="white")+stat_function(fun = dnorm, args = list(mean =m, sd =s))}
else
{ggplot(df, aes_string(x = w))+geom_histogram(aes(y =..density..),bins=40,colour = "black",fill ="white")}
}